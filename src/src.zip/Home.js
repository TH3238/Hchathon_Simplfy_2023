import logo from './logo.svg';
import './App.css';
import { useState } from 'react';
import axios from 'axios';

function Home() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');
  const [clicked, setClicked] = useState(false);


  const translateText = async () => {
    try {
      const response = await fetch('/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          // Include any required data for the Selenium script here
        })
      });
  
      if (response.ok) {
        const result = await response.json();
        // Use the result data as needed
        console.log(result);
        setResult(result);
      } else {
        // Handle error response
        console.error('Error:', response.statusText);
      }
    } catch (error) {
      // Handle network or other errors
      console.error('Error:', error.message);
    }
  };
  
  


  const handleClick = async (e) => {
    setClicked(!clicked);

    // const response = await axios.get(`http://localhost:5000/addFeature/ שכתב לי בבקשה את הטקסט הבא להיות יותר קצר, במשלב לשוני נמוך יותר: ${input}`);
    // console.log(response.data);
    const response = await axios.get(`http://localhost:5000/translate/${input}`);


    // Call the translateText function when needed, e.g., on a button click
    //translateText();
    setResult(response.data);

  }

  const handleChange = ({target}) => {
    const { value } = target;
    //console.log(value);
    setInput(value);
  }



  return (
    
    <div className='container'>

      <textarea className='text' placeholder='הכנס טקסט' onChange={handleChange}></textarea>
      {clicked && <section id='dstText' className='text' value={result == '' ? 'טוען...' : result}>{result}</section>}
      
      <button onClick={handleClick} disabled={input==''}>תרגם</button>

    </div>
  );
}


export default Home;

// function TranslateComponent() {
//   const [text, setText] = useState('');
//   const [translatedText, setTranslatedText] = useState('');
  
//   const translateText = () => {
//     axios
//       .post(
//         'https://translation.googleapis.com/language/translate/v2',
//         {},
//         {
//           params: {
//             q: text,
//             target: 'en', // Target language (e.g., 'en' for English)
//             key: 'YOUR_API_KEY', // Replace with your actual API key
//           },
//         }
//       )
//       .then((response) => {
//         const translation = response.data.data.translations[0].translatedText;
//         setTranslatedText(translation);
//       })
//       .catch((error) => {
//         console.error('Translation error:', error);
//       });
//   };
  
//   // Rest of the component code
// }

// function TranslateComponent() {
//   const [text, setText] = useState('');
//   const [translatedText, setTranslatedText] = useState('');
  
//   const translateText = () => {
//     // Translation request code
//     axios
//       .post(
//         'https://translation.googleapis.com/language/translate/v2',
//         {},
//         {
//           params: {
//             q: text,
//             target: 'en', // Target language (e.g., 'en' for English)
//             key: 'YOUR_API_KEY', // Replace with your actual API key
//           },
//         }
//       )
//       .then((response) => {
//         const translation = response.data.data.translations[0].translatedText;
//         setTranslatedText(translation);
//       })
//       .catch((error) => {
//         console.error('Translation error:', error);
//   };
  
//   return (
//     <div>
//       <input
//         type="text"
//         value={text}
//         onChange={(e) => setText(e.target.value)}
//       />
//       <button onClick={translateText}>Translate</button>
//       <p>{translatedText}</p>
//     </div>
//   );
// }



